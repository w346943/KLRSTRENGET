const corsHeaders = { "content-type": "application/json; charset=utf-8" };
const json = (data, status=200) => new Response(JSON.stringify(data), {status, headers:corsHeaders});
const b64 = (buf) => btoa(String.fromCharCode(...new Uint8Array(buf)));
const unb64 = (s) => Uint8Array.from(atob(s), c=>c.charCodeAt(0));
const hex = (buf) => [...new Uint8Array(buf)].map(x=>x.toString(16).padStart(2,"0")).join("");
const random = (n=32) => { const a=new Uint8Array(n); crypto.getRandomValues(a); return hex(a); };
async function digest(s) { return hex(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s))); }
async function passwordHash(password, salt) {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits({name:"PBKDF2",salt:unb64(salt),iterations:310000,hash:"SHA-256"},key,256);
  return hex(bits);
}
async function sessionUser(req, env) {
  const token = (req.headers.get("cookie")||"").split(";").map(x=>x.trim()).find(x=>x.startsWith("klr_session="))?.slice(12);
  if (!token) return null;
  const row = await env.DB.prepare("SELECT users.id, users.username, users.role FROM sessions JOIN users ON users.id=sessions.user_id WHERE sessions.token_hash=? AND sessions.expires_at>? AND users.disabled=0").bind(await digest(token), Date.now()).first();
  return row || null;
}
async function log(env, userId, action, details="") {
  await env.DB.prepare("INSERT INTO activity(id,owner_id,action,details) VALUES(?,?,?,?)").bind(random(16),userId,action,details).run();
}
async function api(req, env) {
  const url = new URL(req.url), path=url.pathname, method=req.method;
  if (path==="/api/health") return json({ok:true,service:"KLRSTRENGET"});
  if (path==="/api/register" && method==="POST") {
    if (env.ALLOW_REGISTRATION!=="true") return json({error:"التسجيل مغلق"},403);
    const body=await req.json().catch(()=>({}));
    const username=String(body.username||"").trim(), password=String(body.password||"");
    if (!/^[A-Za-z0-9_]{3,24}$/.test(username) || password.length<12) return json({error:"اسم المستخدم 3-24 حرفاً وكلمة المرور 12 حرفاً على الأقل"},400);
    const salt=b64(crypto.getRandomValues(new Uint8Array(16))), hash=await passwordHash(password,salt), id=random(16);
    try { await env.DB.prepare("INSERT INTO users(id,username,password_hash,password_salt) VALUES(?,?,?,?)").bind(id,username,hash,salt).run(); }
    catch { return json({error:"اسم المستخدم مستخدم مسبقاً"},409); }
    return json({ok:true,message:"تم إنشاء الحساب. سجّل الدخول."},201);
  }
  if (path==="/api/login" && method==="POST") {
    const body=await req.json().catch(()=>({})), username=String(body.username||""), password=String(body.password||"");
    const u=await env.DB.prepare("SELECT * FROM users WHERE username=?").bind(username).first();
    if (!u || u.disabled || await passwordHash(password,u.password_salt)!==u.password_hash) return json({error:"بيانات الدخول غير صحيحة"},401);
    const token=random(32), expires=Date.now()+7*24*60*60*1000;
    await env.DB.prepare("INSERT INTO sessions(token_hash,user_id,expires_at) VALUES(?,?,?)").bind(await digest(token),u.id,expires).run();
    return new Response(JSON.stringify({ok:true}),{headers:{"content-type":"application/json","set-cookie":`klr_session=${token}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=604800`}});
  }
  if (path==="/api/logout" && method==="POST") {
    const token=(req.headers.get("cookie")||"").split(";").map(x=>x.trim()).find(x=>x.startsWith("klr_session="))?.slice(12);
    if(token) await env.DB.prepare("DELETE FROM sessions WHERE token_hash=?").bind(await digest(token)).run();
    return new Response("{}",{headers:{"content-type":"application/json","set-cookie":"klr_session=; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=0"}});
  }
  if (path==="/api/fivem/verify" && method==="POST") {
    const body=await req.json().catch(()=>({}));
    const serverId=String(body.server_id||""), license=String(body.license||"");
    const key=req.headers.get("x-server-key")||"";
    if(!serverId||!license||!key) return json({allowed:false,error:"missing_fields"},400);
    const server=await env.DB.prepare("SELECT * FROM servers WHERE id=? AND active=1").bind(serverId).first();
    if(!server || await digest(key)!==server.api_key_hash) return json({allowed:false,error:"unauthorized"},401);
    const p=await env.DB.prepare("SELECT id,permission FROM people WHERE owner_id=? AND license=? AND active=1").bind(server.owner_id,license).first();
    if(!p) return json({allowed:false,permission:null});
    await env.DB.prepare("UPDATE people SET uses=uses+1,last_used=CURRENT_TIMESTAMP WHERE id=?").bind(p.id).run();
    return json({allowed:true,permission:p.permission});
  }
  const user=await sessionUser(req,env);
  if(path==="/api/me") return user?json({user}):json({user:null},401);
  if(!user) return json({error:"يجب تسجيل الدخول"},401);
  if(path==="/api/people" && method==="GET") {
    const {results}=await env.DB.prepare("SELECT id,license,permission,uses,last_used,active,created_at FROM people WHERE owner_id=? ORDER BY created_at DESC").bind(user.id).all();
    return json({people:results});
  }
  if(path==="/api/people" && method==="POST") {
    const body=await req.json().catch(()=>({})), license=String(body.license||"").trim(), permission=String(body.permission||"");
    if(!/^[A-Za-z0-9:_-]{5,100}$/.test(license)||!["owner","rockstar_designer"].includes(permission)) return json({error:"License أو الصلاحية غير صحيحة"},400);
    try { await env.DB.prepare("INSERT INTO people(id,owner_id,license,permission) VALUES(?,?,?,?)").bind(random(16),user.id,license,permission).run(); }
    catch { return json({error:"هذا License مضاف مسبقاً لحسابك"},409); }
    await log(env,user.id,"add_person",license);
    return json({ok:true},201);
  }
  const del=path.match(/^\/api\/people\/([a-f0-9]+)$/);
  if(del && method==="DELETE") {
    const r=await env.DB.prepare("DELETE FROM people WHERE id=? AND owner_id=?").bind(del[1],user.id).run();
    if(!r.meta.changes) return json({error:"غير موجود"},404);
    await log(env,user.id,"delete_person",del[1]);
    return json({ok:true});
  }
  if(path==="/api/activity") {
    const {results}=await env.DB.prepare("SELECT action,details,created_at FROM activity WHERE owner_id=? ORDER BY created_at DESC LIMIT 30").bind(user.id).all();
    return json({activity:results});
  }
  return json({error:"not_found"},404);
}
export default {
 async fetch(req,env) {
   if(new URL(req.url).pathname.startsWith("/api/")) {
     if(!["GET","POST","DELETE"].includes(req.method)) return json({error:"method_not_allowed"},405);
     try{return await api(req,env);}catch(e){return json({error:"server_error"},500);}
   }
   return env.ASSETS.fetch(req);
 }
};
