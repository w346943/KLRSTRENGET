# KLRSTRENGET — الإصدار الأول

**BY KLR وليد**

هذا مشروع بداية فعلي قابل للرفع إلى GitHub والنشر على Cloudflare Workers مع D1.
يتضمن واجهة سوداء/بيضاء بلمسات بنفسجية، API أساسي، قاعدة بيانات متعددة الحسابات،
ومورد FiveM أولي للتحقق من الصلاحيات من جهة السيرفر.

> مهم: هذا إصدار تأسيسي وليس منتجاً مكتملاً أو مدققاً أمنياً. لا تستخدمه على سيرفر إنتاج
> قبل إكمال اختبارات الأمان، إعداد البريد لاستعادة كلمة المرور، ومراجعة إعدادات الاستضافة.
> لم يتم اختبار توافقه مع كل Core من المذكورة؛ مورد FiveM الحالي مستقل عن Core.

## 1) رفعه إلى GitHub
1. فك ضغط الملف.
2. افتح المستودع `KLRSTRENGET` في GitHub.
3. اضغط **Add file → Upload files**.
4. اسحب محتويات المجلد (وليس ملف ZIP نفسه) إلى الصفحة.
5. اضغط **Commit changes**.

## 2) إعداد Cloudflare
يتطلب حساب Cloudflare، Workers، وD1.
1. من Cloudflare افتح Workers & Pages وأنشئ Worker.
2. اربط المستودع GitHub أو استخدم إعدادات النشر من المستودع.
3. أنشئ قاعدة D1 باسم `klrstrenget-db`.
4. نفّذ `database/schema.sql` على قاعدة D1.
5. اربط قاعدة D1 بالـ Worker باسم binding: `DB`.
6. أضف متغير البيئة `ALLOW_REGISTRATION=true` مؤقتاً.
7. انشر Worker. استخدم HTTPS دائماً.

ملف `wrangler.toml` يحتوي إعدادات مبدئية؛ حدّث `database_id` بمعرّف قاعدة D1 الحقيقي.

## 3) إنشاء أول حساب
التسجيل ينشئ حساباً عادياً. لا توجد كلمة مرور مدير ثابتة داخل الملفات.
بعد أول تسجيل، عيّن دور المدير يدوياً من D1 Console بعد التأكد من البريد:
`UPDATE users SET role='admin' WHERE username='اسم_المستخدم';`

لا تضع كلمات مرور أو API keys في ملفات المشروع أو GitHub.

## 4) واجهة الموقع
افتح رابط Worker بعد النشر. مشغل الموسيقى يدعم ملفاً محلياً:
ضع ملفك باسم `music.mp3` داخل `public/`، وصورة الغلاف باسم `cover.jpg`.
لا يتضمن ZIP موسيقى محمية بحقوق نشر. زر الصوت يعمل بعد إضافة الملف.

## 5) FiveM
انسخ `fivem/klrstrenget` إلى resources ثم أضف:
`ensure klrstrenget`
ضع عنوان API ومفتاح السيرفر في `server.cfg` كـ convars، وليس داخل ملفات العميل:
`set klr_api_url "https://YOUR-WORKER.workers.dev"`
`set klr_server_id "YOUR_SERVER_ID"`
`set klr_server_key "YOUR_SERVER_KEY"`

إنشاء/تدوير مفاتيح السيرفر وواجهة الإدارة المتقدمة ما زالت ضمن مراحل التطوير.
لا يعتبر ربط FiveM مكتملاً حتى تضيف endpoint إدارة السيرفرات وإصدار المفاتيح وتختبره.

## المزايا الموجودة حالياً
- تسجيل/دخول بجلسات عشوائية مخزنة كـ hash.
- تخزين كلمات المرور باستخدام PBKDF2.
- فصل سجلات الأشخاص حسب مالك الحساب في استعلامات API.
- إضافة وعرض وحذف سجلات License من الحساب نفسه.
- تسجيل نشاط أساسي.
- تحقق FiveM server-side عبر endpoint `/api/fivem/verify` (يتطلب مفتاحاً تم إدخاله يدوياً في D1).
- واجهة عربية RTL متجاوبة.

## غير مكتمل بعد
- استعادة كلمة المرور عبر البريد.
- MFA، إدارة الجلسات، تدوير المفاتيح من لوحة المدير.
- نظام رفع/توليد حزم Core adapters واختبار QBCore/L1Core/MT-Core/RespectCore/ESX.
- تدقيق أمني واختبارات تحميل واختبارات اختراق.
- لوحة إدارة شاملة وسجل دخول مشبوه متقدم.

## أوامر محلية (بعد تثبيت Node.js وWrangler)
`npm install -g wrangler`
`wrangler d1 create klrstrenget-db`
`wrangler d1 execute klrstrenget-db --file=database/schema.sql`
`wrangler dev`
