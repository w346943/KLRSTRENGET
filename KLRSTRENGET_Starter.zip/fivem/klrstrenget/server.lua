local API = GetConvar('klr_api_url', '')
local SERVER_ID = GetConvar('klr_server_id', '')
local SERVER_KEY = GetConvar('klr_server_key', '')

-- Server-side only. Never move SERVER_KEY into a client script.
RegisterNetEvent('klrstrenget:check', function()
    local src = source
    local license
    for _, identifier in ipairs(GetPlayerIdentifiers(src)) do
        if identifier:sub(1, 8) == 'license:' then license = identifier break end
    end
    if not license or API == '' or SERVER_ID == '' or SERVER_KEY == '' then
        TriggerClientEvent('klrstrenget:result', src, false, nil)
        return
    end
    PerformHttpRequest(API .. '/api/fivem/verify', function(status, body)
        if status ~= 200 or not body then
            TriggerClientEvent('klrstrenget:result', src, false, nil)
            return
        end
        local ok, data = pcall(json.decode, body)
        if not ok or type(data) ~= 'table' then
            TriggerClientEvent('klrstrenget:result', src, false, nil)
            return
        end
        TriggerClientEvent('klrstrenget:result', src, data.allowed == true, data.permission)
    end, 'POST', json.encode({server_id = SERVER_ID, license = license}), {
        ['Content-Type'] = 'application/json',
        ['X-Server-Key'] = SERVER_KEY
    })
end)
