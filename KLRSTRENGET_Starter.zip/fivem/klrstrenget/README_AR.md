# KLRSTRENGET FiveM
أضف المورد إلى resources ثم `ensure klrstrenget`.
ضع القيم التالية في server.cfg بعد تجهيز API والسيرفر في قاعدة البيانات:
set klr_api_url "https://YOUR-WORKER.workers.dev"
set klr_server_id "YOUR_SERVER_ID"
set klr_server_key "YOUR_SERVER_KEY"
الفحص يتم في server.lua فقط. لا يوجد حالياً client.lua لأن المورد يقدم حدث تحقق فقط.
